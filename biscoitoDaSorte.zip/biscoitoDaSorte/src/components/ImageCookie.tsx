import { Component, useState } from 'react';
import { Image, View, Text } from 'react-native';

interface BiscoitoProps {
    aberto: boolean
}

export class ImageCookie extends Component<BiscoitoProps> {
    state = {
        frase: ''
    };

    render() {
        const imgAberto = `../assets/biscoitoAberto.png`;
        const imgFechado = `../assets/biscoitoFechado.png`;
        const estaAberto = this.props.aberto;
        const listaFrases = [
            "Grandes oportunidades estão a caminho.",
            "Uma surpresa agradável vai alegrar seu dia.",
            "A persistência levará você ao sucesso.",
            "Confie na sua intuição.",
            "Boas notícias chegarão em breve.",
            "Um novo caminho se abrirá para você.",
            "A sorte favorece quem se arrisca.",
            "Você encontrará o que procura.",
            "Um gesto gentil fará toda a diferença.",
            "Seu esforço será recompensado."
        ];

        const obterFrase = (): string => listaFrases[Math.random() * listaFrases.length];

        return (
            <View>
                <Image
                    source={
                        this.props.aberto
                            ? require(imgAberto)
                            : require(imgFechado)
                    }
                    style={{ width: 300, height: 300 }}
                />
                <Text>{this.props.aberto ? 'Aberto' : 'Fechado'}</Text>
                <Text>{this.state.frase}</Text>
            </View>
        );
    }
}

