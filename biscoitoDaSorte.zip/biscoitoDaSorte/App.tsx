import { StyleSheet, Text, View } from 'react-native';
import { ImageCookie } from './src/components/ImageCookie';
import { Component } from 'react';

export default class App extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Text>Teste sua sorte!!!</Text>
        <ImageCookie aberto={true} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
